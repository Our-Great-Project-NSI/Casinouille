# -*- coding: utf-8 -*-
"""
Created on Tue Apr 23 13:44:43 2024

@author: hugolormier
"""

class Portefeuille:
    def __init__(self, solde_initial):
        self.solde = solde_initial

    def ajouter(self, montant):
        self.solde += montant

    def retirer(self, montant):
        if montant > self.solde:
            raise ValueError("Solde insuffisant")
        self.solde -= montant
    
    def get_solde(self):
        return self.solde